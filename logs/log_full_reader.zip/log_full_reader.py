#!/usr/bin/env python3

import re
from pathlib import Path
import pandas as pd
from datetime import datetime


def parse_num_workers(log_text: str) -> dict:
    pattern = re.compile(r"workers=(\d+)")
    m = pattern.search(log_text)
    return {"num_workers": m.group(1)} if m else {"num_workers": None}


# ──────────────────────────────
def parse_training_params(log_text: str) -> dict:
    params = {}
    patterns = {
        "batch_size": r"Batch Size\s*:\s*(\d+)",
        "img_size": r"Image Size\s*:\s*(\d+)",
        "epochs": r"Epochs\s*:\s*(\d+)",
        "device": r"Device\s*:\s*(\d+)",
        "weights_path": r"Weights\s*:\s*(.+)",
        "hyp_path": r"Hyperparams\s*:\s*(.+)",
        "output_dir": r"Output Dir\s*:\s*(.+)",
        "extra_args": r"Extra Args\s*:\s*(.+)",
    }
    for key, pat in patterns.items():
        m = re.search(pat, log_text)
        params[key] = m.group(1).strip() if m else None
    return params

# ──────────────────────────────
def parse_epoch_losses(log_text: str, total_epochs: int = None) -> dict:
    pattern = re.compile(
        r"(\d+)/(\d+)\s+([\d\.]+[GM])\s+([\d\.Ee+-]+)\s+([\d\.Ee+-]+)\s+([\d\.Ee+-]+)\s+([\d\.Ee+-]+)"
    )
    matches = list(pattern.finditer(log_text))
    if matches:
        m = matches[-1]
        current_epoch = int(m.group(1))
        max_epoch = int(m.group(2))
        percent = round((current_epoch / max_epoch) * 100, 2) if max_epoch else None
        return {
            "epoch": m.group(1),
            "gpu_mem": m.group(3),
            "box_loss": m.group(4),
            "obj_loss": m.group(5),
            "cls_loss": m.group(6),
            "total_loss": m.group(7),
            "progress_percent": percent
        }
    return {}


# ──────────────────────────────
def parse_val_summary(log_text: str) -> dict:
    summary = {}
    pattern = re.compile(
        r"all\s+(\d+)\s+(\d+)\s+([\d\.Ee+-]+)\s+([\d\.Ee+-]+)\s+([\d\.Ee+-]+)\s+([\d\.Ee+-]+)"
    )
    m = pattern.search(log_text)
    if m:
        summary = {
            "image_count_val": m.group(1),
            "label_count_val": m.group(2),
            "precision": m.group(3),
            "recall": m.group(4),
            "mAP50": m.group(5),
            "mAP50_95": m.group(6),
        }
    return summary

# ──────────────────────────────
def parse_model_summary(log_text: str) -> dict:
    summary = {}
    pattern = re.compile(
        r"Model Summary:\s*(\d+)\s*layers,\s*([\d\.Ee+-]+)\s*parameters.*?([\d\.Ee+-]+)\s*GFLOPS"
    )
    m = pattern.search(log_text)
    if m:
        summary = {
            "layer_count": m.group(1),
            "parameter_count": m.group(2),
            "gflops": m.group(3),
        }
    return summary

# ──────────────────────────────
def parse_save_dir(log_text: str) -> dict:
    pattern = re.compile(r"save_dir='([^']+)'")
    m = pattern.search(log_text)
    return {"save_dir": m.group(1)} if m else {"save_dir": None}

# ──────────────────────────────
def parse_dataset_counts(log_text: str) -> dict:
    counts = {}
    m_train = re.search(r"train.*?(\d+)\s*found.*?(\d+)\s*empty", log_text)
    if m_train:
        counts["image_count_train"] = m_train.group(1)
        counts["empty_image_count"] = m_train.group(2)
    m_val = re.search(r"val.*?(\d+)\s*found", log_text)
    if m_val:
        counts["image_count_val_parsed"] = m_val.group(1)
    return counts

# ──────────────────────────────
def parse_weight_transfer_info(log_text: str) -> dict:
    pattern = re.compile(r"Transferred\s+(\d+/\d+)\s+items")
    m = pattern.search(log_text)
    return {"weight_transfer_info": m.group(1)} if m else {"weight_transfer_info": None}

# ──────────────────────────────
def parse_times(log_text: str) -> dict:
    times = {}
    # Start time
    m_start = re.search(r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) - === Eğitim başlatıldı", log_text)
    # End time
    m_end = re.search(r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) - ✅ Eğitim tamamlandı", log_text)

    if m_start:
        times["start_time"] = m_start.group(1)
    if m_end:
        times["end_time"] = m_end.group(1)

    # Duration
    if m_start and m_end:
        t1 = datetime.strptime(m_start.group(1), "%Y-%m-%d %H:%M:%S")
        t2 = datetime.strptime(m_end.group(1), "%Y-%m-%d %H:%M:%S")
        duration_min = round((t2 - t1).total_seconds() / 60, 2)
        times["duration_min"] = duration_min
        times["status"] = "done"
    else:
        times["duration_min"] = None
        times["status"] = "running"

    return times

# ──────────────────────────────
if __name__ == "__main__":
    log_file = Path(__file__).resolve().parent / "RR_GARNISH_NUT_NEW_2025-06-27_06-03-19.log"

    if not log_file.exists():
        print(f"❌ Log dosyası bulunamadı: {log_file}")
        exit(1)

    with log_file.open("r", encoding="utf-8", errors="ignore") as f:
        log_content = f.read()

    # 🔧 Parse işlemleri
    training_params = parse_training_params(log_content)
    epoch_losses = parse_epoch_losses(log_content)
    val_summary = parse_val_summary(log_content)
    model_summary = parse_model_summary(log_content)
    save_dir = parse_save_dir(log_content)
    dataset_counts = parse_dataset_counts(log_content)
    weight_transfer_info = parse_weight_transfer_info(log_content)
    times = parse_times(log_content)

    # 🔀 Tüm verileri birleştir
    combined_dict = {}
    combined_dict.update(training_params)
    combined_dict.update(epoch_losses)
    combined_dict.update(val_summary)
    combined_dict.update(model_summary)
    combined_dict.update(save_dir)
    combined_dict.update(dataset_counts)
    combined_dict.update(weight_transfer_info)
    combined_dict.update(times)

    # ✅ Tek DataFrame
    df_final = pd.DataFrame([combined_dict])

    # 🔍 Sonucu yazdır
    print("📊 Final Combined DataFrame:")
    print(df_final)

    print("📊 Final Combined DataFrame (dikey gösterim):")
    for col in df_final.columns:
        print(f"{col}: {df_final.iloc[0][col]}")

